# Anonymized XP incident fixture
