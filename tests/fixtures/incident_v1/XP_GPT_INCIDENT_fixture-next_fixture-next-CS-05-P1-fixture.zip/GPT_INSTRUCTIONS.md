Preserve run/incident/challenge bindings.
